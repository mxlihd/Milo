/* Runs in the cloud build right after `npx cap add android`. It makes the generated Android app behave like the game wants:
   landscape only, fullscreen (no nav bars), screen stays on, notch-safe, dark splash, MILO icons.
   Every step is wrapped so a hiccup in one never stops the APK from being built. */
const fs=require('fs'),path=require('path');
const cfg=JSON.parse(fs.readFileSync('capacitor.config.json','utf8'));
const root=path.join('android','app','src','main'),res=path.join(root,'res');
const read=p=>fs.readFileSync(p,'utf8'),write=(p,s)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,s);};
const step=(name,fn)=>{try{fn();console.log('ok   '+name);}catch(e){console.warn('WARN '+name+': '+e.message);}};

step('landscape lock',()=>{
  const f=path.join(root,'AndroidManifest.xml');let m=read(f);
  if(!/screenOrientation/.test(m)){m=m.replace(/<activity\b/,'<activity android:screenOrientation="sensorLandscape"');}
  write(f,m);
});

step('fullscreen + notch + keep awake (MainActivity)',()=>{
  const dir=path.join(root,'java',...cfg.appId.split('.'));
  write(path.join(dir,'MainActivity.java'),`package ${cfg.appId};

import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
    if (Build.VERSION.SDK_INT >= 28) {
      WindowManager.LayoutParams lp = getWindow().getAttributes();
      lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
      getWindow().setAttributes(lp);
    }
    hideBars();
  }

  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) hideBars();
  }

  private void hideBars() {
    WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
    c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    c.hide(WindowInsetsCompat.Type.systemBars());
  }
}
`);
});

step('dark splash + icon background colours',()=>{
  const sf=path.join(res,'values','styles.xml');
  if(fs.existsSync(sf)){write(sf,read(sf).replace(/@drawable\/splash/g,'@color/milo_bg'));}
  write(path.join(res,'values','milo_colors.xml'),'<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="milo_bg">#0b1114</color>\n</resources>\n');
  write(path.join(res,'values','ic_launcher_background.xml'),'<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0b1114</color>\n</resources>\n');
});

step('MILO icons',()=>{
  const src=path.join('resources','android');
  for(const d of fs.readdirSync(src)){
    for(const f of fs.readdirSync(path.join(src,d))){
      const to=path.join(res,d,f);fs.mkdirSync(path.dirname(to),{recursive:true});fs.copyFileSync(path.join(src,d,f),to);
    }
  }
  const adaptive='<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n';
  write(path.join(res,'mipmap-anydpi-v26','ic_launcher.xml'),adaptive);
  write(path.join(res,'mipmap-anydpi-v26','ic_launcher_round.xml'),adaptive);
});

step('version label',()=>{
  const f=path.join('android','app','build.gradle');let g=read(f);
  g=g.replace(/versionName\s+"[^"]*"/,'versionName "v1211"');write(f,g);
});
